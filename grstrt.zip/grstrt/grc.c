      common j,k,l,m,n
      dimension xar(4),yar(4),ichar(4)
      character*80 hed
      hed='this is a test'
      call  GRSTRT(400,400)
      print *,j,k,l,m,n
      call window(-1.,11.,-1.,16.)
      do i=0,15
        call linclr(i)
        yplot=real(i)/1+0.1
        call move(0.,yplot)
        call draw(10.,yplot)
      enddo
      call gflush
      call linclr(1)
      call move(0.,0.)
      call draw(0.,15.)
      call draw(10.,15.)
      call draw(10.,0.)
      call draw(0.,0.)
      call linclr(2)
      call marker(1.,1.,0)
      call text(5,'first')
      call linclr(3)
      call marker(1.,1.,10)
      call linclr(1)
      call marker(2.,2.,1)
      call text(6,'second')
      call move(3.5,3.5)
      call draw(3.5,3.5)
      call point(3.6,3.6)
      call move(5.,5.)
      call text(80,hed)
      call move(5.,6.)
      call linclr(4)
      call text(80,hed)
      call gflush
      do i=1,15
        call linclr(i)
        call move (1.,10.)
        call text (12,'Text Testing')
        call move (1.,9.)
        call text (11,'Is Working!')
        call gflush
        call wait(100000)
      enddo
      call gflush
      if(.true.) then
        call locate(4,xar,yar,ichar,igot)
        print *,(ichar(i),i=1,igot)
        call move(xar(1),yar(1))
        do i=2,igot
          call draw(xar(i),yar(i))
        enddo
        call draw(xar(1),yar(1))
        do i=1,15
          call filpan(i,.false.)
          call panel(igot,xar,yar)
          call wait(100000)
        enddo
      endif
      call gflush
c     call savescreen(1,800,800)
      CALL GRSTOP
      END
      subroutine wait(n)
      sum=0
      do i=1,n
        sum=sum+sin(real(i))
      enddo
      end

